import hashlib
import os
from pathlib import Path
from typing import List
from qdrant_client.models import PointStruct
from app.rag.embeddings import embed_texts
from app.rag.store import get_qdrant_client, ensure_collection, QDRANT_COLLECTION
from app.rag.loaders import SUPPORTED_EXTENSIONS, load_document

DOCS_PATH = Path(os.getenv("DOCS_PATH", "data/docs"))
DOCS_PATH.mkdir(parents=True, exist_ok=True)
CHUNK_SIZE = int(os.getenv("RAG_CHUNK_SIZE", "650"))
CHUNK_OVERLAP = int(os.getenv("RAG_CHUNK_OVERLAP", "80"))

DEMO_DOCS = {
    "hcp_europe.txt": "HCP Europe is suitable when a customer prefers managed service and needs European regional alignment. It is useful when the organization wants faster adoption and reduced platform operations burden.",
    "self_managed.txt": "Self-managed enterprise deployments are appropriate when customers require stronger operational control, strict sovereignty boundaries, customer-hosted infrastructure, or more direct control over compliance implementation.",
    "hybrid.txt": "Hybrid patterns are useful when some workloads can use managed services but sovereignty-sensitive workloads must stay under tighter customer control or local hosting boundaries.",
    "sovereignty.txt": "Sovereignty requirements typically include data residency, operational control, compliance alignment, audit boundaries, and restrictions on external dependencies in regulated or air-gapped environments.",
}


def ensure_demo_docs() -> None:
    for name, text in DEMO_DOCS.items():
        path = DOCS_PATH / name
        if not path.exists():
            path.write_text(text)


def chunk_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> List[str]:
    text = " ".join(text.split())
    if len(text) <= chunk_size:
        return [text]
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        chunks.append(text[start:end])
        if end == len(text):
            break
        start = max(end - overlap, 0)
    return chunks


def _point_id(source: str, index: int) -> int:
    digest = hashlib.sha256(f"{source}:{index}".encode()).hexdigest()[:16]
    return int(digest, 16)


def discover_documents() -> list[Path]:
    return [
        path for path in DOCS_PATH.rglob("*")
        if path.is_file() and path.suffix.lower() in SUPPORTED_EXTENSIONS
    ]


def ingest_documents() -> dict:
    ensure_demo_docs()
    ensure_collection()
    client = get_qdrant_client()

    all_chunks = []
    payloads = []
    ids = []
    discovered = discover_documents()

    for path in discovered:
        text = load_document(path)
        if not text.strip():
            continue
        chunks = chunk_text(text)
        for i, chunk in enumerate(chunks):
            ids.append(_point_id(str(path.relative_to(DOCS_PATH)), i))
            all_chunks.append(chunk)
            payloads.append({
                "source": str(path.relative_to(DOCS_PATH)),
                "filename": path.name,
                "extension": path.suffix.lower(),
                "chunk_index": i,
                "text": chunk,
            })

    if not all_chunks:
        return {"status": "no_documents", "documents": 0, "chunks": 0}

    vectors = embed_texts(all_chunks)
    points = [
        PointStruct(id=ids[i], vector=vectors[i], payload=payloads[i])
        for i in range(len(all_chunks))
    ]
    client.upsert(collection_name=QDRANT_COLLECTION, points=points)
    return {
        "status": "ok",
        "documents": len(discovered),
        "chunks": len(all_chunks),
        "collection": QDRANT_COLLECTION,
    }
