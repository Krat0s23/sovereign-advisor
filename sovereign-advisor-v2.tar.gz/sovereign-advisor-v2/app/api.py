from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional
from app.graph.workflow import run_chat_turn
from app.memory.history import list_threads, get_thread_messages
from app.rag.ingest import ensure_demo_docs, ingest_documents
from app.rag.retrieve import retrieve

app = FastAPI(title="Sovereign Advisor API", version="2.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost", "http://localhost:8501", "http://ui:8501"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1)
    thread_id: str = Field(..., min_length=1)
    user_id: str = Field(default="default-user")
    mode: str = Field(default="auto")

class ChatResponse(BaseModel):
    answer: str
    thread_id: str
    mode: str
    recommendation: Optional[dict] = None
    retrieved_docs: List[str] = []

class IngestResponse(BaseModel):
    status: str
    documents: int
    chunks: int
    collection: Optional[str] = None

@app.on_event("startup")
def startup_event():
    ensure_demo_docs()
    ingest_documents()

@app.get("/")
def home():
    return {"message": "Sovereign Advisor API running"}

@app.post("/chat", response_model=ChatResponse)
def chat(payload: ChatRequest):
    result = run_chat_turn(
        thread_id=payload.thread_id,
        user_id=payload.user_id,
        message=payload.message,
        mode=payload.mode,
    )
    return ChatResponse(**result)

@app.post("/rag/ingest", response_model=IngestResponse)
def rag_ingest():
    return IngestResponse(**ingest_documents())

@app.get("/rag/search")
def rag_search(query: str, limit: int = 3):
    return {"results": retrieve(query, limit=limit)}

@app.get("/threads")
def threads():
    return {"threads": list_threads()}

@app.get("/history/{thread_id}")
def history(thread_id: str):
    return {"thread_id": thread_id, "messages": get_thread_messages(thread_id)}
