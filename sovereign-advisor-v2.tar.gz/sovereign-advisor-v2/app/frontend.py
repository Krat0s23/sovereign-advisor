import os
import uuid
import requests
import streamlit as st

API_BASE_URL = os.getenv("API_BASE_URL", "http://localhost:8000")

st.set_page_config(page_title="Sovereign Advisor", page_icon="🛡️", layout="wide")

if "thread_id" not in st.session_state:
    st.session_state.thread_id = str(uuid.uuid4())
if "messages" not in st.session_state:
    st.session_state.messages = []
if "mode" not in st.session_state:
    st.session_state.mode = "auto"

with st.sidebar:
    st.title("Sovereign Advisor")
    st.caption("Air-gapped conversational advisor")
    st.session_state.mode = st.selectbox(
        "Conversation mode",
        ["auto", "chat", "advisor"],
        index=["auto", "chat", "advisor"].index(st.session_state.mode),
    )
    if st.button("Start new conversation"):
        st.session_state.thread_id = str(uuid.uuid4())
        st.session_state.messages = []
        st.rerun()
    st.write("Thread ID")
    st.code(st.session_state.thread_id)
    st.markdown("### What this bot can do")
    st.markdown("- Normal conversational chat\n- Sovereignty-aware recommendation flow\n- Local history retention\n- RAG-grounded responses")

st.title("🛡️ Sovereign Advisor")
st.write("Ask free-form questions or describe customer requirements for a recommendation.")

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg.get("recommendation"):
            st.json(msg["recommendation"])
        if msg.get("retrieved_docs"):
            st.caption("Retrieved docs: " + ", ".join(msg["retrieved_docs"]))

prompt = st.chat_input("Ask about HCP vs self-managed, sovereignty, compliance, or architecture...")
if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    payload = {
        "message": prompt,
        "thread_id": st.session_state.thread_id,
        "user_id": "default-user",
        "mode": st.session_state.mode,
    }
    try:
        response = requests.post(f"{API_BASE_URL}/chat", json=payload, timeout=180)
        response.raise_for_status()
        result = response.json()
        assistant_message = {
            "role": "assistant",
            "content": result["answer"],
            "recommendation": result.get("recommendation"),
            "retrieved_docs": result.get("retrieved_docs", []),
        }
        st.session_state.messages.append(assistant_message)
        with st.chat_message("assistant"):
            st.markdown(result["answer"])
            if result.get("recommendation"):
                st.json(result["recommendation"])
            if result.get("retrieved_docs"):
                st.caption("Retrieved docs: " + ", ".join(result["retrieved_docs"]))
    except Exception as exc:
        error_msg = f"Backend error: {exc}"
        st.session_state.messages.append({"role": "assistant", "content": error_msg})
        with st.chat_message("assistant"):
            st.error(error_msg)
